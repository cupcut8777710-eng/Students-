/* =========================================
   STUDENT STUDY ASSISTANT
   STAGE 5 JAVASCRIPT
========================================= */


/* =========================================
   STORAGE KEYS
========================================= */

const MARKS_STORAGE_KEY =
    "studentStudyAssistantMarks";

const PROFILE_STORAGE_KEY =
    "studentStudyAssistantProfile";

const THEME_STORAGE_KEY =
    "studyAssistantTheme";

const TIMETABLE_STORAGE_KEY =
    "studentStudyAssistantTimetable";

const MARKS_HISTORY_STORAGE_KEY =
    "studentStudyAssistantMarksHistory";


/* =========================================
   GLOBAL VARIABLES
========================================= */

let performanceChart = null;


/* =========================================
   DOM ELEMENTS
========================================= */

// Navigation
const navButtons =
    document.querySelectorAll(".nav-button");

const quickActionButtons =
    document.querySelectorAll(".quick-action");

const pages =
    document.querySelectorAll(".page");


// Theme
const themeButton =
    document.getElementById("themeButton");


// Profile
const studentName =
    document.getElementById("studentName");

const profileForm =
    document.getElementById("profileForm");

const profileNameInput =
    document.getElementById("profileNameInput");

const targetPercentageInput =
    document.getElementById("targetPercentageInput");

const dailyStudyGoalInput =
    document.getElementById("dailyStudyGoalInput");

const profileMessage =
    document.getElementById("profileMessage");

const homeTarget =
    document.getElementById("homeTarget");

const homeTargetMessage =
    document.getElementById("homeTargetMessage");

const homeDailyGoal =
    document.getElementById("homeDailyGoal");

const homeTargetGap =
    document.getElementById("homeTargetGap");

const homeTargetGapText =
    document.getElementById("homeTargetGapText");


// Marks
const marksForm =
    document.getElementById("marksForm");

const subjectInput =
    document.getElementById("subjectInput");

const maximumInput =
    document.getElementById("maximumInput");

const obtainedInput =
    document.getElementById("obtainedInput");

const marksList =
    document.getElementById("marksList");

const marksHistoryList =
    document.getElementById("marksHistoryList");

const emptyMarks =
    document.getElementById("emptyMarks");

const clearMarksButton =
    document.getElementById("clearMarksButton");

const marksMessage =
    document.getElementById("marksMessage");


// Home
const homePercentage =
    document.getElementById("homePercentage");

const homeProgressBar =
    document.getElementById("homeProgressBar");

const homeSubjects =
    document.getElementById("homeSubjects");

const homeStrong =
    document.getElementById("homeStrong");

const homeWeak =
    document.getElementById("homeWeak");

const homePerformanceBadge =
    document.getElementById(
        "homePerformanceBadge"
    );

const bestSubject =
    document.getElementById("bestSubject");

const bestSubjectPercentage =
    document.getElementById(
        "bestSubjectPercentage"
    );

const weakestSubject =
    document.getElementById(
        "weakestSubject"
    );

const weakestSubjectPercentage =
    document.getElementById(
        "weakestSubjectPercentage"
    );


// Marks summary
const marksCount =
    document.getElementById("marksCount");

const marksOverall =
    document.getElementById("marksOverall");

const marksStrong =
    document.getElementById("marksStrong");

const marksWeak =
    document.getElementById("marksWeak");


// Analysis
const chartPercentage =
    document.getElementById(
        "chartPercentage"
    );

const performanceChartElement =
    document.getElementById(
        "performanceChart"
    );

const analysisLevel =
    document.getElementById(
        "analysisLevel"
    );

const analysisEmoji =
    document.getElementById(
        "analysisEmoji"
    );

const analysisMessage =
    document.getElementById(
        "analysisMessage"
    );

const analysisBest =
    document.getElementById(
        "analysisBest"
    );

const analysisBestText =
    document.getElementById(
        "analysisBestText"
    );

const analysisWeakest =
    document.getElementById(
        "analysisWeakest"
    );

const analysisWeakestText =
    document.getElementById(
        "analysisWeakestText"
    );

const analysisList =
    document.getElementById(
        "analysisList"
    );


// Toast
const toast =
    document.getElementById("toast");


/* =========================================
   STAGE 5 TIMETABLE ELEMENTS
========================================= */

const timetableForm =
    document.getElementById(
        "timetableForm"
    );

const studyHoursInput =
    document.getElementById(
        "studyHours"
    );

const schoolStartInput =
    document.getElementById(
        "schoolStart"
    );

const schoolEndInput =
    document.getElementById(
        "schoolEnd"
    );

const sleepTimeInput =
    document.getElementById(
        "sleepTime"
    );

const wakeTimeInput =
    document.getElementById(
        "wakeTime"
    );

const studyStyleInput =
    document.getElementById(
        "studyStyle"
    );

const studyGoalInput =
    document.getElementById(
        "studyGoal"
    );

const timetableMessage =
    document.getElementById(
        "timetableMessage"
    );

const subjectPriorityList =
    document.getElementById(
        "subjectPriorityList"
    );

const fullDayTimetable =
    document.getElementById(
        "fullDayTimetable"
    );

const nightTimetable =
    document.getElementById(
        "nightTimetable"
    );

const totalStudyMinutes =
    document.getElementById(
        "totalStudyMinutes"
    );

const totalBreakMinutes =
    document.getElementById(
        "totalBreakMinutes"
    );

const weakSubjectMinutes =
    document.getElementById(
        "weakSubjectMinutes"
    );

const timetableSessions =
    document.getElementById(
        "timetableSessions"
    );

const regenerateTimetableButton =
    document.getElementById(
        "regenerateTimetableButton"
    );


/* =========================================
   NAVIGATION
========================================= */

function showPage(pageId) {

    pages.forEach(function (page) {

        page.classList.remove(
            "active-page"
        );

    });


    const selectedPage =
        document.getElementById(pageId);


    if (selectedPage) {

        selectedPage.classList.add(
            "active-page"
        );

        // Redraw after Analysis becomes visible.
        if (pageId === "analysisPage") {
            requestAnimationFrame(function () {
                updateChart();
            });
        }

    }


    navButtons.forEach(function (button) {

        button.classList.toggle(
            "active",
            button.dataset.page === pageId
        );

    });


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =========================================
   BOTTOM NAVIGATION
========================================= */

navButtons.forEach(function (button) {

    button.addEventListener(
        "click",
        function () {

            showPage(
                button.dataset.page
            );

        }
    );

});


/* =========================================
   QUICK ACTION BUTTONS
========================================= */

quickActionButtons.forEach(
    function (button) {

        button.addEventListener(
            "click",
            function () {

                showPage(
                    button.dataset.page
                );

            }
        );

    }
);


/* =========================================
   GET MARKS
========================================= */

function getMarks() {

    try {

        const saved =
            localStorage.getItem(
                MARKS_STORAGE_KEY
            );


        if (!saved) {
            return [];
        }


        const parsed =
            JSON.parse(saved);


        return Array.isArray(parsed)
            ? parsed
            : [];

    } catch (error) {

        console.error(
            "Could not load marks:",
            error
        );

        return [];

    }

}


/* =========================================
   SAVE MARKS
========================================= */

function saveMarks(marks) {

    localStorage.setItem(
        MARKS_STORAGE_KEY,
        JSON.stringify(marks)
    );

}


/* =========================================
   PROFILE
========================================= */

function getProfile() {

    try {

        const saved =
            localStorage.getItem(
                PROFILE_STORAGE_KEY
            );


        if (!saved) {
            return {};
        }


        const parsed =
            JSON.parse(saved);


        if (
            parsed &&
            typeof parsed === "object"
        ) {
            return parsed;
        }


        return {};

    } catch (error) {

        return {};

    }

}


function loadProfile() {

    const profile = getProfile();

    const name = profile.name || "Student";
    const target = Number(profile.targetPercentage) || 80;
    const dailyGoal = Number(profile.dailyStudyGoal) || 180;

    if (studentName) {
        studentName.textContent = name;
    }

    if (profileNameInput) {
        profileNameInput.value = profile.name || "";
    }

    if (targetPercentageInput) {
        targetPercentageInput.value = target;
    }

    if (dailyStudyGoalInput) {
        dailyStudyGoalInput.value = dailyGoal;
    }

    updateDashboardGoals();

}


/* =========================================
   MARK HISTORY
========================================= */

function getMarksHistory() {
    try {
        const saved = localStorage.getItem(MARKS_HISTORY_STORAGE_KEY);
        if (!saved) return [];
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
        return [];
    }
}

function saveMarksHistory(history) {
    localStorage.setItem(
        MARKS_HISTORY_STORAGE_KEY,
        JSON.stringify(history.slice(0, 50))
    );
}

function addMarkHistory(mark) {
    const history = getMarksHistory();
    history.unshift({ ...mark });
    saveMarksHistory(history);
    renderMarksHistory();
}

function renderMarksHistory() {
    if (!marksHistoryList) return;

    const history = getMarksHistory().slice(0, 8);

    if (history.length === 0) {
        marksHistoryList.innerHTML = `
            <div class="empty-state">
                <span>🕘</span>
                <h3>No mark history yet</h3>
                <p>Your recent mark updates will appear here.</p>
            </div>
        `;
        return;
    }

    marksHistoryList.innerHTML = history.map(mark => {
        const date = mark.createdAt
            ? new Date(mark.createdAt).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })
            : "Recent";

        return `
            <div class="history-item">
                <div>
                    <strong>${escapeHTML(mark.subject)}</strong>
                    <small>${date} · ${Number(mark.obtained)} / ${Number(mark.maximum)}</small>
                </div>
                <div class="history-score">
                    <strong>${formatPercentage(mark.percentage)}%</strong>
                    <small>${getStatus(mark.percentage).name}</small>
                </div>
            </div>
        `;
    }).join("");
}


/* =========================================
   DASHBOARD GOALS
========================================= */

function updateDashboardGoals() {
    const profile = getProfile();
    const target = Math.min(100, Math.max(1, Number(profile.targetPercentage) || 80));
    const dailyGoal = Math.min(720, Math.max(15, Number(profile.dailyStudyGoal) || 180));
    const overall = calculateOverall(getMarks());
    const gap = Math.max(0, target - overall);

    if (homeTarget) homeTarget.textContent = target + "%";
    if (homeDailyGoal) homeDailyGoal.textContent = dailyGoal;
    if (homeTargetGap) homeTargetGap.textContent = formatPercentage(gap) + "%";

    if (homeTargetMessage) {
        homeTargetMessage.textContent = overall >= target
            ? "Target reached — keep maintaining it!"
            : "Current: " + formatPercentage(overall) + "%";
    }

    if (homeTargetGapText) {
        homeTargetGapText.textContent = overall >= target
            ? "You're on target."
            : formatPercentage(gap) + "% more needed.";
    }
}


/* =========================================
   STATUS
========================================= */

function getStatus(percentage) {

    if (percentage >= 80) {

        return {
            name: "Strong",
            label: "Strong",
            emoji: "💪",
            className: "strong"
        };

    }


    if (percentage >= 50) {

        return {
            name: "Average",
            label: "Average",
            emoji: "📘",
            className: "average"
        };

    }


    return {
        name: "Weak",
        label: "Needs Focus",
        emoji: "🎯",
        className: "weak"
    };

}


/* =========================================
   PERFORMANCE LEVEL
========================================= */

function getPerformanceLevel(
    percentage
) {

    if (percentage >= 90) {

        return {
            level: "Excellent",
            emoji: "🏆",
            message:
                "Excellent performance! Keep up the great work."
        };

    }


    if (percentage >= 80) {

        return {
            level: "Very Good",
            emoji: "🌟",
            message:
                "Very good performance! Keep improving."
        };

    }


    if (percentage >= 70) {

        return {
            level: "Good",
            emoji: "👍",
            message:
                "Good performance. A little more practice can make it even better."
        };

    }


    if (percentage >= 50) {

        return {
            level: "Needs Improvement",
            emoji: "📚",
            message:
                "You can improve. Give extra attention to your weaker subjects."
        };

    }


    return {
        level: "Needs Serious Improvement",
        emoji: "🎯",
        message:
            "Start with your weakest subjects and follow a consistent study plan."
    };

}


/* =========================================
   IMPROVEMENT TIP
========================================= */

function getImprovementTip(
    percentage
) {

    if (percentage < 50) {

        return "High priority: practice basics, revise concepts and solve questions regularly.";

    }


    if (percentage < 70) {

        return "Medium priority: revise weak topics and practice more questions.";

    }


    if (percentage < 80) {

        return "Keep practicing and focus on mistakes to move into the strong range.";

    }


    return "Maintain your performance with revision, tests and regular practice.";

}


/* =========================================
   FORMAT PERCENTAGE
========================================= */

function formatPercentage(
    value
) {

    return Number(value || 0)
        .toFixed(1);

}


/* =========================================
   CALCULATE OVERALL
========================================= */

function calculateOverall(marks) {

    if (
        !marks ||
        marks.length === 0
    ) {

        return 0;

    }


    let totalObtained = 0;

    let totalMaximum = 0;


    marks.forEach(function (mark) {

        totalObtained +=
            Number(mark.obtained) || 0;

        totalMaximum +=
            Number(mark.maximum) || 0;

    });


    if (totalMaximum <= 0) {

        return 0;

    }


    return (
        totalObtained /
        totalMaximum
    ) * 100;

}


/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* =========================================
   RENDER MARKS
========================================= */

function renderMarks() {

    const marks = getMarks();


    if (!marksList) {
        return;
    }


    marksList.innerHTML = "";


    if (
        emptyMarks
    ) {

        emptyMarks.style.display =
            marks.length === 0
                ? "block"
                : "none";

    }


    marks.forEach(function (mark) {

        const status =
            getStatus(
                Number(mark.percentage)
            );


        const card =
            document.createElement("div");


        card.className =
            "mark-card";


        card.innerHTML = `

            <div class="mark-card-top">

                <div>

                    <div class="mark-subject">
                        ${escapeHTML(
                            mark.subject
                        )}
                    </div>

                    <div class="mark-details">

                        <span>
                            ${mark.obtained}
                            /
                            ${mark.maximum}
                        </span>

                        <span
                            class="mark-status
                            ${status.className}"
                        >
                            ${status.name}
                        </span>

                    </div>

                </div>


                <div
                    style="
                        display:flex;
                        align-items:center;
                        gap:8px;
                    "
                >

                    <span class="mark-percentage">
                        ${formatPercentage(
                            mark.percentage
                        )}%
                    </span>

                    <button
                        class="delete-mark-button"
                        data-id="${mark.id}"
                        type="button"
                        aria-label="Delete mark"
                    >
                        🗑️
                    </button>

                </div>

            </div>


            <div class="mark-progress">

                <div
                    class="mark-progress-bar"
                    style="
                        width:${Math.max(
                            0,
                            Math.min(
                                100,
                                Number(
                                    mark.percentage
                                )
                            )
                        )}%
                    "
                ></div>

            </div>

        `;


        marksList.appendChild(card);

    });


    updateMarksSummary();
    updatePerformance();
    updateAnalysis();
    updateChart();

}
// ============================================================
// PART 2 — PERFORMANCE, ANALYSIS & MARKS CONTROLS
// ============================================================


// ------------------------------------------------------------
// UPDATE MARKS SUMMARY
// ------------------------------------------------------------

function updateMarksSummary() {
    const marks = getMarks();

    const count = marks.length;

    let totalObtained = 0;
    let totalMaximum = 0;
    let strong = 0;
    let weak = 0;

    marks.forEach(mark => {
        totalObtained += Number(mark.obtained);
        totalMaximum += Number(mark.maximum);

        if (Number(mark.percentage) >= 80) {
            strong++;
        }

        if (Number(mark.percentage) < 50) {
            weak++;
        }
    });

    const overall =
        totalMaximum > 0
            ? (totalObtained / totalMaximum) * 100
            : 0;

    if (marksCount) {
        marksCount.textContent = count;
    }

    if (marksOverall) {
        marksOverall.textContent =
            formatPercentage(overall) + "%";
    }

    if (marksStrong) {
        marksStrong.textContent = strong;
    }

    if (marksWeak) {
        marksWeak.textContent = weak;
    }
}


// ------------------------------------------------------------
// UPDATE HOME PERFORMANCE
// ------------------------------------------------------------

function updatePerformance() {
    const marks = getMarks();

    const overall = calculateOverall(marks);
    const level = getPerformanceLevel(overall);

    if (homePercentage) {
        homePercentage.textContent =
            formatPercentage(overall) + "%";
    }

    if (homeProgressBar) {
        homeProgressBar.style.width =
            Math.min(Math.max(overall, 0), 100) + "%";
    }

    if (homeSubjects) {
        homeSubjects.textContent = marks.length;
    }

    const strongCount = marks.filter(
        mark => Number(mark.percentage) >= 80
    ).length;

    const weakCount = marks.filter(
        mark => Number(mark.percentage) < 50
    ).length;

    if (homeStrong) {
        homeStrong.textContent = strongCount;
    }

    if (homeWeak) {
        homeWeak.textContent = weakCount;
    }

    if (homePerformanceBadge) {
        homePerformanceBadge.textContent =
            level.emoji + " " + level.name;
    }

    updateBestAndWeakest();
    updateDashboardGoals();
}


// ------------------------------------------------------------
// BEST & WEAKEST SUBJECT
// ------------------------------------------------------------

function updateBestAndWeakest() {
    const marks = getMarks();

    if (marks.length === 0) {
        if (bestSubject) bestSubject.textContent = "—";
        if (bestSubjectPercentage) {
            bestSubjectPercentage.textContent = "0%";
        }

        if (weakestSubject) {
            weakestSubject.textContent = "—";
        }

        if (weakestSubjectPercentage) {
            weakestSubjectPercentage.textContent = "0%";
        }

        return;
    }

    const sorted = [...marks].sort(
        (a, b) =>
            Number(b.percentage) -
            Number(a.percentage)
    );

    const best = sorted[0];
    const weakest = sorted[sorted.length - 1];

    if (bestSubject) {
        bestSubject.textContent = best.subject;
    }

    if (bestSubjectPercentage) {
        bestSubjectPercentage.textContent =
            formatPercentage(best.percentage) + "%";
    }

    if (weakestSubject) {
        weakestSubject.textContent =
            weakest.subject;
    }

    if (weakestSubjectPercentage) {
        weakestSubjectPercentage.textContent =
            formatPercentage(weakest.percentage) + "%";
    }
}


// ------------------------------------------------------------
// UPDATE ANALYSIS
// ------------------------------------------------------------

function updateAnalysis() {
    const marks = getMarks();

    const overall = calculateOverall(marks);
    const level = getPerformanceLevel(overall);

    if (analysisLevel) {
        analysisLevel.textContent =
            level.name;
    }

    if (analysisEmoji) {
        analysisEmoji.textContent =
            level.emoji;
    }

    if (analysisMessage) {
        if (marks.length === 0) {
            analysisMessage.textContent =
                "Enter your marks to get a personalized performance analysis.";
        } else {
            analysisMessage.textContent =
                level.message;
        }
    }

    if (marks.length > 0) {
        const sorted = [...marks].sort(
            (a, b) =>
                Number(b.percentage) -
                Number(a.percentage)
        );

        const best = sorted[0];
        const weakest = sorted[sorted.length - 1];

        if (analysisBest) {
            analysisBest.textContent =
                best.subject;
        }

        if (analysisBestText) {
            analysisBestText.textContent =
                `${best.subject} is your strongest subject with ${formatPercentage(best.percentage)}%. Keep maintaining this performance.`;
        }

        if (analysisWeakest) {
            analysisWeakest.textContent =
                weakest.subject;
        }

        if (analysisWeakestText) {
            analysisWeakestText.textContent =
                `${weakest.subject} needs the most attention with ${formatPercentage(weakest.percentage)}%. Give it extra practice time.`;
        }
    } else {
        if (analysisBest) {
            analysisBest.textContent = "—";
        }

        if (analysisBestText) {
            analysisBestText.textContent =
                "Add marks to identify your strongest subject.";
        }

        if (analysisWeakest) {
            analysisWeakest.textContent = "—";
        }

        if (analysisWeakestText) {
            analysisWeakestText.textContent =
                "Add marks to identify which subject needs improvement.";
        }
    }

    renderAnalysisList();
}


// ------------------------------------------------------------
// ANALYSIS SUBJECT LIST
// ------------------------------------------------------------

function renderAnalysisList() {
    if (!analysisList) return;

    const marks = getMarks();

    if (marks.length === 0) {
        analysisList.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📊</div>
                <h3>No analysis yet</h3>
                <p>Add your subject marks to see your analysis.</p>
            </div>
        `;

        return;
    }

    const sorted = [...marks].sort(
        (a, b) =>
            Number(a.percentage) -
            Number(b.percentage)
    );

    analysisList.innerHTML = sorted.map(mark => {

        const percentage =
            Number(mark.percentage);

        const status =
            getStatus(percentage);

        const tip =
            getImprovementTip(percentage);

        return `
            <div class="analysis-item">

                <div class="analysis-item-top">

                    <div>
                        <strong>${escapeHTML(mark.subject)}</strong>

                        <div class="analysis-status">
                            ${status.emoji}
                            ${status.label}
                        </div>
                    </div>

                    <div class="analysis-item-percentage">
                        ${formatPercentage(percentage)}%
                    </div>

                </div>

                <div class="mark-progress">
                    <div
                        class="mark-progress-bar"
                        style="width:${Math.min(percentage, 100)}%"
                    ></div>
                </div>

                <p>
                    💡 ${escapeHTML(tip)}
                </p>

            </div>
        `;
    }).join("");
}


// ------------------------------------------------------------
// UPDATE DOUGHNUT CHART
// ------------------------------------------------------------

function updateChart() {
    const marks = getMarks();

    if (!performanceChartElement) return;

    const overall = Math.max(0, Math.min(100, calculateOverall(marks)));
    const remaining = Math.max(0, 100 - overall);

    // Draw the chart directly on canvas so the app also works
    // inside Android WebView/offline without depending on Chart.js CDN.
    const canvas = performanceChartElement;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const size = Math.max(180, Math.min(rect.width || 270, rect.height || 270));
    const dpr = window.devicePixelRatio || 1;

    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = size + "px";
    canvas.style.height = size + "px";

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, size, size);

    const center = size / 2;
    const radius = Math.max(55, size * 0.36);
    const lineWidth = Math.max(18, size * 0.12);
    const startAngle = -Math.PI / 2;

    // Background ring.
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.strokeStyle = "#e5e7eb";
    ctx.lineWidth = lineWidth;
    ctx.lineCap = "round";
    ctx.stroke();

    // Performance ring.
    if (overall > 0) {
        ctx.beginPath();
        ctx.arc(
            center,
            center,
            radius,
            startAngle,
            startAngle + (Math.PI * 2 * overall / 100)
        );
        ctx.strokeStyle = "#2563eb";
        ctx.lineWidth = lineWidth;
        ctx.lineCap = "round";
        ctx.stroke();
    }

    // Percentage in the middle.
    ctx.fillStyle = "#172033";
    ctx.font = "700 " + Math.round(size * 0.14) + "px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(formatPercentage(overall) + "%", center, center);

    if (chartPercentage) {
        chartPercentage.textContent = formatPercentage(overall);
    }
}


// ------------------------------------------------------------
// MARKS FORM SUBMIT
// ------------------------------------------------------------

if (marksForm) {

    marksForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();

            const subject =
                subjectInput.value.trim();

            const maximum =
                Number(maximumInput.value);

            const obtained =
                Number(obtainedInput.value);

            if (!subject) {
                showMessage(
                    marksMessage,
                    "Please enter a subject name.",
                    "error"
                );

                return;
            }

            if (
                !maximum ||
                maximum <= 0
            ) {
                showMessage(
                    marksMessage,
                    "Please enter a valid maximum mark.",
                    "error"
                );

                return;
            }

            if (
                obtained < 0 ||
                obtained > maximum
            ) {
                showMessage(
                    marksMessage,
                    "Obtained marks must be between 0 and maximum marks.",
                    "error"
                );

                return;
            }

            const percentage =
                (obtained / maximum) * 100;

            const marks =
                getMarks();

            const existingIndex =
                marks.findIndex(
                    mark =>
                        mark.subject.toLowerCase() ===
                        subject.toLowerCase()
                );

            const newMark = {
                id: Date.now(),
                subject: subject,
                maximum: maximum,
                obtained: obtained,
                percentage: percentage,
                createdAt:
                    new Date().toISOString()
            };

            if (existingIndex !== -1) {

                marks[existingIndex] =
                    newMark;

                showMessage(
                    marksMessage,
                    `${subject} marks updated successfully.`,
                    "success"
                );

            } else {

                marks.push(newMark);

                showMessage(
                    marksMessage,
                    `${subject} marks added successfully.`,
                    "success"
                );
            }

            saveMarks(marks);
            addMarkHistory(newMark);

            renderMarks();

            marksForm.reset();

            if (maximumInput) {
                maximumInput.value = 100;
            }

            showToast(
                `${subject} marks saved successfully!`
            );
        }
    );
}


// ------------------------------------------------------------
// TIMETABLE GENERATOR
// ------------------------------------------------------------
function timeToMinutes(value) {
    if (!value || !value.includes(":")) return NaN;
    const parts = value.split(":").map(Number);
    return parts[0] * 60 + parts[1];
}

function minutesToTime(total) {
    total = ((total % 1440) + 1440) % 1440;
    const h = Math.floor(total / 60);
    const m = total % 60;
    return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
}

function addMinutesToTime(value, minutes) {
    return minutesToTime(timeToMinutes(value) + minutes);
}

function timetableSubjects() {
    return getMarks()
        .map(mark => ({
            subject: mark.subject,
            percentage: Number(mark.percentage) || 0
        }))
        .sort((a, b) => a.percentage - b.percentage);
}

function renderTimetableBlock(container, items, emptyTitle, emptyText) {
    if (!container) return;

    if (!items.length) {
        container.innerHTML = `
            <div class="empty-state">
                <span>📅</span>
                <h3>${emptyTitle}</h3>
                <p>${emptyText}</p>
            </div>`;
        return;
    }

    container.innerHTML = items.map(item => `
        <div class="timetable-item ${item.type}">
            <div class="timetable-time">${item.start} – ${item.end}</div>
            <div class="timetable-content">
                <strong>${item.icon || "📚"} ${item.title}</strong>
                <small>${item.subtitle || ""}</small>
            </div>
        </div>
    `).join("");
}

function generateTimetable() {
    if (!timetableForm) return;

    const hours = Number(studyHoursInput && studyHoursInput.value);
    const schoolStart = timeToMinutes(schoolStartInput && schoolStartInput.value);
    const schoolEnd = timeToMinutes(schoolEndInput && schoolEndInput.value);
    const sleepTime = timeToMinutes(sleepTimeInput && sleepTimeInput.value);
    const wakeTime = timeToMinutes(wakeTimeInput && wakeTimeInput.value);
    const sessionStyle = studyStyleInput ? studyStyleInput.value : "balanced";
    const goal = studyGoalInput ? studyGoalInput.value : "improve";
    const subjects = timetableSubjects();

    if (!Number.isFinite(hours) || hours < 0.5 || hours > 12) {
        showMessage(timetableMessage, "Study time must be between 0.5 and 12 hours.", "error");
        return;
    }

    if (![schoolStart, schoolEnd, sleepTime, wakeTime].every(Number.isFinite)) {
        showMessage(timetableMessage, "Please enter valid school and sleep times.", "error");
        return;
    }

    if (schoolStart >= schoolEnd) {
        showMessage(timetableMessage, "School start time must be before school end time.", "error");
        return;
    }

    if (subjects.length === 0) {
        showMessage(timetableMessage, "Add at least one subject mark before generating a timetable.", "error");
        return;
    }

    const sessionLength = sessionStyle === "short" ? 30 : sessionStyle === "focus" ? 60 : 45;
    const requestedStudy = Math.round(hours * 60);
    const maxSessions = Math.max(1, Math.ceil(requestedStudy / sessionLength));
    const studyMinutes = Math.min(requestedStudy, maxSessions * sessionLength);
    const breakMinutes = Math.max(5, Math.round(studyMinutes / 4 / 5) * 5);

    // Prefer the evening gap between school and sleep. If it is too small,
    // use the morning gap between wake-up and school instead.
    const eveningStart = schoolEnd;
    const eveningEnd = sleepTime > schoolEnd ? sleepTime : sleepTime + 1440;
    const morningStart = wakeTime;
    const morningEnd = schoolStart > wakeTime ? schoolStart : schoolStart + 1440;
    const eveningAvailable = Math.max(0, eveningEnd - eveningStart);
    const morningAvailable = Math.max(0, morningEnd - morningStart);
    const available = eveningAvailable + morningAvailable;

    if (available < sessionLength) {
        showMessage(timetableMessage, "There is not enough free time between school and sleep for a study session.", "error");
        return;
    }

    const usableStudy = Math.min(studyMinutes, Math.max(sessionLength, available - 10));
    const sessions = Math.max(1, Math.floor(usableStudy / sessionLength));
    const actualStudy = sessions * sessionLength;
    const actualBreak = Math.max(0, (sessions - 1) * 10);
    const items = [];
    let current = eveningStart;

    // Schedule in the evening first, then morning if needed.
    const windows = [
        { start: eveningStart, end: eveningEnd },
        { start: morningStart, end: morningEnd }
    ];
    let subjectIndex = 0;
    let weakMinutes = 0;
    let remainingSessions = sessions;

    windows.forEach(window => {
        if (remainingSessions <= 0) return;
        let cursor = window.start;
        const possible = Math.floor((window.end - window.start) / sessionLength);
        const count = Math.min(possible, remainingSessions);

        for (let i = 0; i < count; i++) {
            const subject = subjects[subjectIndex % subjects.length];
            const start = minutesToTime(cursor);
            const end = minutesToTime(cursor + sessionLength);
            items.push({
                type: "study",
                icon: "📚",
                start,
                end,
                title: subject.subject,
                subtitle: subject.percentage < 60 ? "Priority subject" : goal === "exam" ? "Exam preparation" : "Focused study"
            });
            if (subject.percentage < 60) weakMinutes += sessionLength;
            subjectIndex++;
            remainingSessions--;
            cursor += sessionLength;

            if (remainingSessions > 0 && i < count - 1) {
                items.push({
                    type: "break",
                    icon: "☕",
                    start: minutesToTime(cursor),
                    end: minutesToTime(cursor + 10),
                    title: "Short Break",
                    subtitle: "Rest and reset"
                });
                cursor += 10;
            }
        }
    });

    // Add fixed school and sleep blocks so the generated plan is easy to read.
    const fixedItems = [
        { type: "school", icon: "🏫", start: minutesToTime(schoolStart), end: minutesToTime(schoolEnd), title: "School", subtitle: "School hours" },
        { type: "sleep", icon: "😴", start: minutesToTime(sleepTime), end: minutesToTime(sleepTime + 480), title: "Sleep", subtitle: "Rest and recovery" }
    ];

    renderTimetableBlock(fullDayTimetable, fixedItems.concat(items).sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start)), "No timetable yet", "Generate your plan to see your day.");
    renderTimetableBlock(nightTimetable, items.filter(item => item.type === "study" || item.type === "break"), "No night plan yet", "Your evening study sessions will appear here.");

    if (totalStudyMinutes) totalStudyMinutes.textContent = actualStudy;
    if (totalBreakMinutes) totalBreakMinutes.textContent = actualBreak;
    if (weakSubjectMinutes) weakSubjectMinutes.textContent = weakMinutes;
    if (timetableSessions) timetableSessions.textContent = sessions;

    if (subjectPriorityList) {
        subjectPriorityList.innerHTML = subjects.map((subject, index) => `
            <div class="priority-item">
                <div><strong>${index + 1}. ${subject.subject}</strong><small>${formatPercentage(subject.percentage)}%</small></div>
                <div class="priority-bar"><span style="width:${Math.max(5, Math.min(100, 100 - subject.percentage))}%"></span></div>
            </div>
        `).join("");
    }

    localStorage.setItem("studyTimetable", JSON.stringify({ generatedAt: new Date().toISOString(), hours, sessionLength, goal }));
    showMessage(timetableMessage, "Timetable generated successfully.", "success");
    showToast("Timetable generated successfully!");
}

if (timetableForm) {
    timetableForm.addEventListener("submit", function (event) {
        // IMPORTANT: stop the browser from submitting/reloading the page.
        event.preventDefault();
        event.stopPropagation();
        generateTimetable();
    });
}

if (regenerateTimetableButton) {
    regenerateTimetableButton.addEventListener("click", function (event) {
        event.preventDefault();
        generateTimetable();
    });
}

// ------------------------------------------------------------
// DELETE ONE MARK
// ------------------------------------------------------------

document.addEventListener(
    "click",
    function(event) {

        const button =
            event.target.closest(
                ".delete-mark-button"
            );

        if (!button) return;

        const id =
            Number(button.dataset.id);

        const marks =
            getMarks();

        const updatedMarks =
            marks.filter(
                mark =>
                    Number(mark.id) !== id
            );

        saveMarks(updatedMarks);

        renderMarks();

        showToast(
            "Mark deleted successfully."
        );
    }
);


// ------------------------------------------------------------
// CLEAR ALL MARKS
// ------------------------------------------------------------

if (clearMarksButton) {

    clearMarksButton.addEventListener(
        "click",
        function() {

            const marks =
                getMarks();

            if (marks.length === 0) {
                showToast(
                    "There are no marks to clear."
                );

                return;
            }

            const confirmed =
                confirm(
                    "Are you sure you want to delete all marks?"
                );

            if (!confirmed) {
                return;
            }

            localStorage.removeItem(
                MARKS_STORAGE_KEY
            );

            renderMarks();

            showToast(
                "All marks have been cleared."
            );
        }
    );
}


// ------------------------------------------------------------
// HELPER — SHOW FORM MESSAGE
// ------------------------------------------------------------

function showMessage(
    element,
    message,
    type
) {

    if (!element) return;

    element.textContent =
        message;

    element.className =
        "form-message " + type;

    setTimeout(
        function() {

            if (element) {
                element.textContent = "";
                element.className =
                    "form-message";
            }

        },
        3500
    );
}

// ============================================================
// PART 3 — THEME, PROFILE & FINAL INITIALIZATION
// ============================================================

function applySavedTheme() {
    const savedTheme = localStorage.getItem(THEME_STORAGE_KEY);
    const isDark = savedTheme === "dark";

    document.body.classList.toggle("dark-mode", isDark);

    if (themeButton) {
        themeButton.textContent = isDark ? "☀️" : "🌙";
        themeButton.setAttribute(
            "aria-label",
            isDark ? "Switch to light mode" : "Switch to dark mode"
        );
    }
}

if (themeButton) {
    themeButton.addEventListener("click", function () {
        const isDark = !document.body.classList.contains("dark-mode");
        document.body.classList.toggle("dark-mode", isDark);
        localStorage.setItem(THEME_STORAGE_KEY, isDark ? "dark" : "light");
        applySavedTheme();
    });
}

if (profileForm) {
    profileForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const name = profileNameInput.value.trim();
        const target = Number(targetPercentageInput.value);
        const dailyGoal = Number(dailyStudyGoalInput.value);

        if (!name) {
            showMessage(profileMessage, "Please enter your name.", "error");
            return;
        }

        if (!Number.isFinite(target) || target < 1 || target > 100) {
            showMessage(profileMessage, "Target must be between 1% and 100%.", "error");
            return;
        }

        if (!Number.isFinite(dailyGoal) || dailyGoal < 15 || dailyGoal > 720) {
            showMessage(profileMessage, "Daily study goal must be between 15 and 720 minutes.", "error");
            return;
        }

        localStorage.setItem(
            PROFILE_STORAGE_KEY,
            JSON.stringify({
                name: name,
                targetPercentage: target,
                dailyStudyGoal: dailyGoal,
                updatedAt: new Date().toISOString()
            })
        );

        loadProfile();
        showMessage(profileMessage, "Profile saved successfully.", "success");
        showToast("Profile updated!");
    });
}

applySavedTheme();
loadProfile();
renderMarks();
renderMarksHistory();

